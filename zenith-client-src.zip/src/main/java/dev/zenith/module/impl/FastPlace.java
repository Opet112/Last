package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import dev.zenith.mixin.MinecraftClientAccessor;

public class FastPlace extends Module {
    private final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 0, 0, 4, 1));

    public FastPlace() {
        super("FastPlace", "Removes the delay between placing / using items.", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (!mc.options.useKey.isPressed()) return;
        var acc = (MinecraftClientAccessor) (Object) mc;
        if (acc.zenith$getItemUseCooldown() > delay.getInt()) acc.zenith$setItemUseCooldown(delay.getInt());
    }
}
