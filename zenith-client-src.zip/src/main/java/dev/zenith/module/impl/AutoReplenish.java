package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

public class AutoReplenish extends Module {
    private final Setting.Num threshold = add(new Setting.Num("Refill at", 8, 1, 32, 1));
    private final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 4, 1, 20, 1));
    private int wait;

    public AutoReplenish() {
        super("AutoReplenish", "Refills low hotbar stacks from your inventory.", Category.PLAYER);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (wait-- > 0) return;
        for (int h = 0; h < 9; h++) {
            ItemStack s = p.getInventory().getStack(h);
            if (s.isEmpty() || s.getMaxCount() <= 1 || s.getCount() > threshold.getInt()) continue;
            for (int i = 9; i < 36; i++) {
                ItemStack other = p.getInventory().getStack(i);
                if (!other.isEmpty() && other.isOf(s.getItem())) {
                    mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, i, 0, SlotActionType.QUICK_MOVE, p);
                    wait = delay.getInt();
                    return;
                }
            }
        }
    }
}
