package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.BlockUtil;
import dev.zenith.util.DamageUtil;
import dev.zenith.util.EntityUtil;
import dev.zenith.util.InventoryUtil;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Respawn anchors only explode outside the Nether: place anchor -> charge with glowstone -> right-click
 * with anything else. Needs a respawn anchor and glowstone in the hotbar. Do not sneak while it runs.
 */
public class AnchorAura extends Module {
    private static final float POWER = 5.0f;

    private final Setting.Num range = add(new Setting.Num("Range", 4.5, 2.0, 6.0, 0.1));
    private final Setting.Num targetRange = add(new Setting.Num("Target range", 8, 4, 14, 1));
    private final Setting.Num minDamage = add(new Setting.Num("Min damage", 5, 1, 20, 0.5));
    private final Setting.Num maxSelf = add(new Setting.Num("Max self damage", 6, 1, 20, 0.5));
    private final Setting.Num delay = add(new Setting.Num("Delay", 2, 0, 10, 1));

    private BlockPos anchor;
    private int wait;

    public AnchorAura() {
        super("AnchorAura", "Blows up respawn anchors next to the closest player (not in the Nether).", Category.COMBAT);
    }

    @Override
    protected void onDisable() { anchor = null; }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (mc.world.getRegistryKey() == World.NETHER) return;
        if (wait-- > 0) return;

        PlayerEntity target = EntityUtil.nearestPlayer(targetRange.get());
        if (target == null) { anchor = null; return; }

        if (anchor != null) {
            BlockState state = mc.world.getBlockState(anchor);
            if (!state.isOf(Blocks.RESPAWN_ANCHOR) || p.getEyePos().distanceTo(Vec3d.ofCenter(anchor)) > range.get() + 1) {
                anchor = null;
            } else {
                handleAnchor(state, target);
                return;
            }
        }
        placeAnchor(target);
    }

    private void handleAnchor(BlockState state, PlayerEntity target) {
        var p = mc.player;
        int charges = state.get(RespawnAnchorBlock.CHARGES);
        Vec3d center = Vec3d.ofCenter(anchor);

        if (charges == 0) {
            int glow = InventoryUtil.findHotbar(Items.GLOWSTONE);
            if (glow < 0) return;
            InventoryUtil.select(glow);
            interact(anchor);
        } else {
            float self = DamageUtil.explosion(center, p, POWER);
            if (self > maxSelf.get() || self >= p.getHealth() + p.getAbsorptionAmount() - 1f) return;
            if (DamageUtil.explosion(center, target, POWER) < 1f) return;
            int safe = InventoryUtil.findHotbar(s -> s.isEmpty() || !s.isOf(Items.GLOWSTONE));
            if (safe < 0) return;
            InventoryUtil.select(safe);
            interact(anchor);
        }
        wait = delay.getInt();
    }

    private void placeAnchor(PlayerEntity target) {
        var p = mc.player;
        int slot = InventoryUtil.findHotbar(Items.RESPAWN_ANCHOR);
        if (slot < 0 || InventoryUtil.findHotbar(Items.GLOWSTONE) < 0) return;

        int r = (int) Math.ceil(range.get());
        BlockPos origin = p.getBlockPos();
        Vec3d eye = p.getEyePos();
        BlockPos best = null;
        double bestScore = -Double.MAX_VALUE;
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    BlockPos pos = origin.add(dx, dy, dz);
                    if (!BlockUtil.canPlaceAt(pos) || !BlockUtil.hasSupport(pos)) continue;
                    if (eye.distanceTo(Vec3d.ofCenter(pos)) > range.get()) continue;
                    if (!mc.world.getOtherEntities(null, new Box(pos)).isEmpty()) continue;
                    Vec3d c = Vec3d.ofCenter(pos);
                    float dt = DamageUtil.explosion(c, target, POWER);
                    if (dt < minDamage.get()) continue;
                    float ds = DamageUtil.explosion(c, p, POWER);
                    if (ds > maxSelf.get() || ds >= p.getHealth() + p.getAbsorptionAmount() - 1f) continue;
                    double score = dt - ds * 0.5;
                    if (score > bestScore) { bestScore = score; best = pos; }
                }
            }
        }
        if (best == null) return;
        InventoryUtil.select(slot);
        if (BlockUtil.place(best, Hand.MAIN_HAND, true)) {
            anchor = best;
            wait = delay.getInt();
        }
    }

    private void interact(BlockPos pos) {
        var p = mc.player;
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(Vec3d.ofCenter(pos), Direction.UP, pos, false));
        p.swingHand(Hand.MAIN_HAND);
    }
}
