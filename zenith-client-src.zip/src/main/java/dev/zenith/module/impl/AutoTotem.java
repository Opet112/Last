package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Module {
    private final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 1, 0, 10, 1));
    private int wait;

    public AutoTotem() {
        super("AutoTotem", "Keeps a Totem of Undying in your offhand.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) { wait = delay.getInt(); return; }
        if (wait-- > 0) return;

        for (int i = 0; i < 36; i++) {
            if (!p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) continue;
            int slot = i < 9 ? 36 + i : i; // hotbar -> 36..44, main inventory -> 9..35
            mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);
            wait = delay.getInt();
            return;
        }
    }
}
