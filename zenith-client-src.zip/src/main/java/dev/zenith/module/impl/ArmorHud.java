package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

public class ArmorHud extends Module {
    private static final EquipmentSlot[] ORDER = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    public ArmorHud() {
        super("ArmorHUD", "Shows your armor and durability next to the hotbar.", Category.RENDER);
    }

    @Override
    public void onRender(DrawContext ctx) {
        var p = mc.player;
        if (p == null) return;
        int x = mc.getWindow().getScaledWidth() / 2 + 96;
        int y = mc.getWindow().getScaledHeight() - 20;
        for (EquipmentSlot slot : ORDER) {
            ItemStack stack = p.getEquippedStack(slot);
            if (!stack.isEmpty()) {
                ctx.drawItem(stack, x, y);
                ctx.drawStackOverlay(mc.textRenderer, stack, x, y);
            }
            x += 18;
        }
    }
}
