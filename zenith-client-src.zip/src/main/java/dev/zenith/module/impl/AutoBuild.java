package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.BlockUtil;
import dev.zenith.util.InventoryUtil;
import net.minecraft.item.BlockItem;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Builds a small structure around/in front of you from the blocks in your hotbar, then switches itself off. */
public class AutoBuild extends Module {
    private final Setting.Mode shape = add(new Setting.Mode("Shape", "Box", "Box", "Platform", "Wall", "Tower"));
    private final Setting.Num perTick = add(new Setting.Num("Blocks/tick", 2, 1, 4, 1));
    private final Setting.Bool swing = add(new Setting.Bool("Swing", true));

    private final List<BlockPos> plan = new ArrayList<>();
    private int idle;

    public AutoBuild() {
        super("AutoBuild", "Builds a box, platform, wall or tower with hotbar blocks.", Category.PLAYER);
    }

    private static BlockPos at(BlockPos b, int x, int y, int z) {
        return new BlockPos(b.getX() + x, b.getY() + y, b.getZ() + z);
    }

    @Override
    protected void onEnable() {
        plan.clear();
        idle = 0;
        if (mc.player == null) return;
        BlockPos feet = BlockPos.ofFloored(mc.player.getX(), mc.player.getY(), mc.player.getZ());
        Direction f = mc.player.getHorizontalFacing();
        int fx = f.getVector().getX(), fz = f.getVector().getZ();
        switch (shape.get()) {
            case "Platform" -> {
                for (int x = -2; x <= 2; x++) for (int z = -2; z <= 2; z++) plan.add(at(feet, x, -1, z));
            }
            case "Wall" -> {
                // 5 wide, 3 high, two blocks in front of you
                for (int h = 0; h < 3; h++) for (int s = -2; s <= 2; s++) {
                    plan.add(at(feet, fx * 2 + (fz != 0 ? s : 0), h, fz * 2 + (fx != 0 ? s : 0)));
                }
            }
            case "Tower" -> {
                for (int h = 0; h < 6; h++) plan.add(at(feet, 0, h, 0));
            }
            default -> {
                // shelter: floor, walls around you (2 high) and a roof
                for (int x = -1; x <= 1; x++) for (int z = -1; z <= 1; z++) {
                    plan.add(at(feet, x, -1, z));
                    plan.add(at(feet, x, 2, z));
                    if (x != 0 || z != 0) { plan.add(at(feet, x, 0, z)); plan.add(at(feet, x, 1, z)); }
                }
            }
        }
        plan.sort(Comparator.comparingInt(BlockPos::getY));
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null) return;
        int slot = InventoryUtil.findHotbar(s -> s.getItem() instanceof BlockItem);
        if (slot < 0) { setEnabled(false); return; }
        InventoryUtil.select(slot);

        int placed = 0;
        var it = plan.iterator();
        while (it.hasNext() && placed < perTick.getInt()) {
            BlockPos pos = it.next();
            if (!BlockUtil.canPlaceAt(pos)) { it.remove(); continue; }
            if (p.getEyePos().squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 20.0) continue;
            // the tower and box need the player out of the block being placed
            if (BlockUtil.place(pos, Hand.MAIN_HAND, swing.get())) { placed++; it.remove(); }
        }
        if (plan.isEmpty()) { setEnabled(false); return; }
        if (placed == 0 && ++idle > 100) setEnabled(false); // nothing reachable / supported any more
        else if (placed > 0) idle = 0;
    }
}
