package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

/** Makes other players easier to hit by enlarging how far from their box your crosshair still counts. */
public class HitBoxes extends Module {
    private static HitBoxes instance;
    private final Setting.Num expand = add(new Setting.Num("Expand", 0.15, 0.0, 0.5, 0.05));

    public HitBoxes() {
        super("HitBoxes", "Expands other players' hitboxes for your crosshair.", Category.COMBAT);
        instance = this;
    }

    public static float expansion(Entity e) {
        if (instance == null || !instance.isEnabled() || !(e instanceof PlayerEntity) || e == mc.player) return 0f;
        if (EntityUtil.isFriend(e)) return 0f;
        return (float) instance.expand.get();
    }
}
