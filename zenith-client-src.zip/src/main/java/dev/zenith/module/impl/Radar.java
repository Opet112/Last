package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;

public class Radar extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 40, 10, 128, 5));
    private final Setting.Num size = add(new Setting.Num("Size", 80, 50, 140, 10));
    private final Setting.Bool hostiles = add(new Setting.Bool("Hostiles", true));

    public Radar() {
        super("Radar", "2D radar showing nearby players and mobs.", Category.RENDER);
    }

    @Override
    public void onRender(DrawContext ctx) {
        var p = mc.player;
        if (p == null || mc.world == null) return;
        int s = size.getInt();
        int x = 4, y = 100;
        int cx = x + s / 2, cy = y + s / 2;
        ctx.fill(x, y, x + s, y + s, 0x90101216);
        ctx.fill(x, y, x + s, y + 1, ColorUtil.accent(0));
        ctx.fill(x, cy, x + s, cy + 1, 0x30FFFFFF);
        ctx.fill(cx, y, cx + 1, y + s, 0x30FFFFFF);
        ctx.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFFFFFF);

        double yaw = Math.toRadians(p.getYaw());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        double scale = (s / 2.0 - 3) / range.get();

        for (Entity e : mc.world.getEntities()) {
            if (e == p) continue;
            int color;
            if (e instanceof PlayerEntity) color = EntityUtil.isFriend(e) ? 0xFF35D6E8 : 0xFFFF4D4D;
            else if (hostiles.get() && e instanceof HostileEntity) color = 0xFFFFB347;
            else continue;
            double dx = e.getX() - p.getX(), dz = e.getZ() - p.getZ();
            double right = -dx * cos - dz * sin;
            double forward = -dx * sin + dz * cos;
            int px = cx + (int) Math.round(right * scale);
            int py = cy - (int) Math.round(forward * scale);
            if (px < x + 1 || px > x + s - 3 || py < y + 1 || py > y + s - 3) continue;
            ctx.fill(px, py, px + 3, py + 3, color);
        }
    }
}
