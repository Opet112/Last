package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

public class Sneak extends Module {
    public Sneak() {
        super("Sneak", "Holds the sneak key for you.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.currentScreen == null) mc.options.sneakKey.setPressed(true);
    }

    @Override
    protected void onDisable() { mc.options.sneakKey.setPressed(false); }
}
