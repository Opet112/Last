package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.DrawUtil;
import dev.zenith.util.Projector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;

/** Draws the path you walked so you can find your way back. */
public class Breadcrumbs extends Module {
    private final Setting.Num length = add(new Setting.Num("Points", 300, 50, 1000, 50));
    private final ArrayDeque<Vec3d> trail = new ArrayDeque<>();
    private String dim = "";

    public Breadcrumbs() {
        super("Breadcrumbs", "Trail of your recent path.", Category.RENDER);
    }

    @Override
    protected void onEnable() { trail.clear(); }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        String d = mc.world.getRegistryKey().getValue().toString();
        if (!d.equals(dim)) { trail.clear(); dim = d; }
        Vec3d p = new Vec3d(mc.player.getX(), mc.player.getY() + 0.1, mc.player.getZ());
        if (trail.isEmpty() || trail.peekLast().squaredDistanceTo(p) > 1.0) trail.addLast(p);
        while (trail.size() > length.getInt()) trail.pollFirst();
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.world == null || trail.size() < 2) return;
        Projector pr = Projector.create(ZenithClient.partial());
        if (pr == null) return;
        double[] last = null;
        int i = 0;
        for (Vec3d v : trail) {
            double[] s = pr.project(v);
            if (s != null && last != null) DrawUtil.line(ctx, last[0], last[1], s[0], s[1], ColorUtil.accent(i / 10), pr.width, pr.height);
            last = s;
            i++;
        }
    }
}
