package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import net.minecraft.client.network.ClientPlayerEntity;

public class Flight extends Module {
    private final Setting.Num speed = add(new Setting.Num("Speed", 1.0, 0.1, 5.0, 0.1));
    private final Setting.Num vertical = add(new Setting.Num("Vertical", 0.6, 0.1, 3.0, 0.1));

    private final Setting.Bool antiKick = add(new Setting.Bool("Anti-kick", true));
    private int kickTimer;

    public Flight() {
        super("Flight", "Fly freely in survival.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;

        double forward = (mc.options.forwardKey.isPressed() ? 1 : 0) - (mc.options.backKey.isPressed() ? 1 : 0);
        double strafe = (mc.options.leftKey.isPressed() ? 1 : 0) - (mc.options.rightKey.isPressed() ? 1 : 0);
        double yaw = Math.toRadians(p.getYaw());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);

        double mx = 0, mz = 0;
        if (forward != 0 || strafe != 0) {
            double len = Math.sqrt(forward * forward + strafe * strafe);
            forward /= len;
            strafe /= len;
            mx = (-sin * forward + cos * strafe) * speed.get();
            mz = (cos * forward + sin * strafe) * speed.get();
        }
        double my = 0;
        if (mc.options.jumpKey.isPressed()) my += vertical.get();
        if (mc.options.sneakKey.isPressed()) my -= vertical.get();

        // vanilla kicks for "floating" after ~80 ticks without downward movement
        if (antiKick.get() && my == 0 && ++kickTimer >= 20) { kickTimer = 0; my = -0.04; }
        p.setVelocity(mx, my, mz);
    }

    @Override
    public String getSuffix() { return "Vanilla"; }
}
