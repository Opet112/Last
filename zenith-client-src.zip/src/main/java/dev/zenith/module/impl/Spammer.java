package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

public class Spammer extends Module {
    /** Set with the .spammer command. */
    public static String message = "Zenith client";

    private final Setting.Num seconds = add(new Setting.Num("Delay (s)", 10, 2, 120, 1));
    private int timer;

    public Spammer() {
        super("Spammer", "Repeats a chat message (set it with .spammer <text>).", Category.MISC);
    }

    @Override
    protected void onEnable() { timer = 0; }

    @Override
    public void onTick() {
        if (mc.getNetworkHandler() == null) return;
        if (++timer >= seconds.getInt() * 20) {
            timer = 0;
            mc.getNetworkHandler().sendChatMessage(message);
        }
    }
}
