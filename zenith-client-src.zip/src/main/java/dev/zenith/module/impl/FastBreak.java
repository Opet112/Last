package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import dev.zenith.mixin.InteractionManagerAccessor;

public class FastBreak extends Module {
    public FastBreak() {
        super("NoBreakDelay", "Removes the cooldown between breaking blocks.", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (mc.interactionManager == null || !mc.options.attackKey.isPressed()) return;
        ((InteractionManagerAccessor) (Object) mc.interactionManager).zenith$setBlockBreakingCooldown(0);
    }
}
