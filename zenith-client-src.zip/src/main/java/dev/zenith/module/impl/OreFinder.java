package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.DrawUtil;
import dev.zenith.util.Projector;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Scans the blocks the server actually sent and only reports ore clusters. Anti-xray plugins scatter single fake
 * ores through hidden stone, so requiring a minimum cluster size filters most of them out.
 */
public class OreFinder extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 24, 8, 48, 4));
    private final Setting.Num minCluster = add(new Setting.Num("Min cluster", 2, 1, 6, 1));
    private final Setting.Bool lowValue = add(new Setting.Bool("Iron/Gold/Lapis", false));

    private final Map<Long, Block> next = new HashMap<>();
    private volatile Map<Long, Block> shown = new HashMap<>();
    private int layer;

    public OreFinder() {
        super("OreFinder", "Shows ore clusters through walls; ignores lone (likely fake) ores.", Category.RENDER);
    }

    @Override
    protected void onEnable() { layer = 0; next.clear(); shown = new HashMap<>(); }

    private boolean wanted(Block b) {
        if (b == Blocks.DIAMOND_ORE || b == Blocks.DEEPSLATE_DIAMOND_ORE || b == Blocks.ANCIENT_DEBRIS
                || b == Blocks.EMERALD_ORE || b == Blocks.DEEPSLATE_EMERALD_ORE) return true;
        if (!lowValue.get()) return false;
        return b == Blocks.GOLD_ORE || b == Blocks.DEEPSLATE_GOLD_ORE || b == Blocks.NETHER_GOLD_ORE
                || b == Blocks.IRON_ORE || b == Blocks.DEEPSLATE_IRON_ORE
                || b == Blocks.LAPIS_ORE || b == Blocks.DEEPSLATE_LAPIS_ORE;
    }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null) return;
        int r = range.getInt();
        int px = (int) Math.floor(mc.player.getX()), py = (int) Math.floor(mc.player.getY()), pz = (int) Math.floor(mc.player.getZ());
        int dx = layer - r;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dz = -r; dz <= r; dz++) {
            for (int dy = -r; dy <= r; dy++) {
                m.set(px + dx, py + dy, pz + dz);
                Block b = mc.world.getBlockState(m).getBlock();
                if (wanted(b)) next.put(m.asLong(), b);
            }
        }
        layer++;
        if (layer > r * 2) {
            layer = 0;
            shown = filter(new HashMap<>(next));
            next.clear();
        }
    }

    private Map<Long, Block> filter(Map<Long, Block> all) {
        int min = minCluster.getInt();
        if (min <= 1) return all;
        Map<Long, Block> keep = new HashMap<>();
        Set<Long> seen = new HashSet<>();
        for (Long start : all.keySet()) {
            if (seen.contains(start)) continue;
            Set<Long> group = new HashSet<>();
            ArrayDeque<Long> queue = new ArrayDeque<>();
            queue.add(start);
            seen.add(start);
            while (!queue.isEmpty()) {
                long cur = queue.poll();
                group.add(cur);
                BlockPos p = BlockPos.fromLong(cur);
                for (int x = -1; x <= 1; x++) for (int y = -1; y <= 1; y++) for (int z = -1; z <= 1; z++) {
                    long n = BlockPos.asLong(p.getX() + x, p.getY() + y, p.getZ() + z);
                    if (all.containsKey(n) && seen.add(n)) queue.add(n);
                }
            }
            if (group.size() >= min) for (Long g : group) keep.put(g, all.get(g));
        }
        return keep;
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.world == null) return;
        Projector pr = Projector.create(ZenithClient.partial());
        if (pr == null) return;
        for (Map.Entry<Long, Block> e : shown.entrySet()) {
            double[] s = pr.box(new Box(BlockPos.fromLong(e.getKey())));
            if (s == null) continue;
            int color = e.getValue() == Blocks.ANCIENT_DEBRIS ? 0xFFB5651D
                    : (e.getValue() == Blocks.EMERALD_ORE || e.getValue() == Blocks.DEEPSLATE_EMERALD_ORE) ? 0xFF2FD27E : 0xFF35D6E8;
            DrawUtil.outline(ctx, (int) s[0], (int) s[1], (int) s[2], (int) s[3], color);
        }
    }
}
