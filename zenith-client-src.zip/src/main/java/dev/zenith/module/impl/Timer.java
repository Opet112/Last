package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

public class Timer extends Module {
    private static Timer instance;
    private final Setting.Num multiplier = add(new Setting.Num("Speed", 1.2, 0.1, 3.0, 0.05));

    public Timer() {
        super("Timer", "Runs the game faster or slower (also changes how fast your inputs are sent).", Category.MOVEMENT);
        instance = this;
    }

    public static double speed() {
        return instance != null && instance.isEnabled() ? instance.multiplier.get() : 1.0;
    }

    @Override
    public String getSuffix() { return String.format("%.2fx", multiplier.get()); }
}
