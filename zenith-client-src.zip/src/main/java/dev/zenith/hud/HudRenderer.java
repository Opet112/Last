package dev.zenith.hud;

import dev.zenith.ZenithClient;
import dev.zenith.module.Module;
import dev.zenith.module.impl.HudModule;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.CpsCounter;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class HudRenderer {
    private HudRenderer() {}

    public static void render(DrawContext ctx) {
        CpsCounter.update();
        MinecraftClient mc = MinecraftClient.getInstance();
        HudModule hud = ZenithClient.modules().get(HudModule.class);
        if (hud == null || !hud.isEnabled() || mc.player == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;

        int y = 4;
        if (hud.watermark.get()) {
            String title = ZenithClient.NAME;
            int accent = ColorUtil.accent(0);
            ctx.fill(2, 2, 14 + tr.getWidth(title) + 4 + tr.getWidth(ZenithClient.VERSION) + 4, 15, 0x90101216);
            ctx.fill(2, 2, 4, 15, accent);
            dev.zenith.util.ZeusTheme.bolt(ctx, 7, 2, 12, 5L + (System.currentTimeMillis() / 700L), dev.zenith.util.ZeusTheme.GOLD, 100000, 100000);
            ctx.drawText(tr, title, 14, 5, accent, true);
            ctx.drawText(tr, ZenithClient.VERSION, 14 + tr.getWidth(title) + 4, 5, ColorUtil.TEXT_DIM, true);
            y = 19;
        }
        List<String> lines = new ArrayList<>();
        if (hud.fps.get()) lines.add(mc.getCurrentFps() + " FPS");
        if (hud.coords.get()) {
            lines.add(String.format("XYZ %.1f / %.1f / %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ()));
        }
        if (hud.speed.get()) lines.add(String.format("%.1f b/s", hud.bps));
        if (hud.ping.get() && mc.getNetworkHandler() != null) {
            var entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (entry != null) lines.add(entry.getLatency() + " ms");
        }
        if (hud.direction.get()) {
            String f = mc.player.getHorizontalFacing().asString();
            lines.add(Character.toUpperCase(f.charAt(0)) + f.substring(1));
        }
        if (hud.cps.get()) lines.add(CpsCounter.left() + " | " + CpsCounter.right() + " CPS");
        for (String line : lines) {
            ctx.drawText(tr, line, 4, y, ColorUtil.TEXT, true);
            y += 10;
        }

        if (hud.arrayList.get()) renderArrayList(ctx, tr, mc.getWindow().getScaledWidth());

        dev.zenith.module.impl.Printer printer = ZenithClient.modules().get(dev.zenith.module.impl.Printer.class);
        if (printer != null) {
            try { printer.previewRender(ctx); } catch (Throwable t) { /* preview is cosmetic */ }
        }
        for (Module m : ZenithClient.modules().all()) {
            if (!m.isEnabled()) continue;
            try {
                m.onRender(ctx);
            } catch (Throwable t) {
                ZenithClient.LOGGER.error("Module {} failed while rendering and was disabled", m.name, t);
                m.setEnabled(false);
            }
        }
    }

    private static void renderArrayList(DrawContext ctx, TextRenderer tr, int screenWidth) {
        List<Module> active = new ArrayList<>();
        for (Module m : ZenithClient.modules().all()) if (m.isEnabled() && m.visible) active.add(m);
        active.sort(Comparator.comparingInt((Module m) -> -tr.getWidth(label(m))));

        int y = 2;
        int i = 0;
        for (Module m : active) {
            String text = label(m);
            int w = tr.getWidth(text);
            int x = screenWidth - w - 6;
            int color = ColorUtil.accent(i++);
            ctx.fill(x - 2, y, screenWidth, y + 11, 0x90101216);
            ctx.fill(screenWidth - 2, y, screenWidth, y + 11, color);
            ctx.drawText(tr, text, x, y + 2, color, true);
            y += 11;
        }
    }

    private static String label(Module m) {
        String suffix = m.getSuffix();
        return suffix == null ? m.name : m.name + " " + suffix;
    }
}
