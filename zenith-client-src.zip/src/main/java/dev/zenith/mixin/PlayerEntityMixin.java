package dev.zenith.mixin;

import dev.zenith.module.impl.NoPush;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin {
    @Inject(method = "isPushedByFluids", at = @At("HEAD"), cancellable = true, require = 0)
    private void zenith$noFluidPush(CallbackInfoReturnable<Boolean> cir) {
        if (NoPush.blocksFluids((Entity) (Object) this)) cir.setReturnValue(false);
    }
}
