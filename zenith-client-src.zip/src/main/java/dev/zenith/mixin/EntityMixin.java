package dev.zenith.mixin;

import dev.zenith.module.impl.Freecam;
import dev.zenith.module.impl.HitBoxes;
import dev.zenith.module.impl.NoPush;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "getTargetingMargin", at = @At("RETURN"), cancellable = true, require = 0)
    private void zenith$hitbox(CallbackInfoReturnable<Float> cir) {
        float extra = HitBoxes.expansion((Entity) (Object) this);
        if (extra > 0f) cir.setReturnValue(cir.getReturnValueF() + extra);
    }

    @Inject(method = "pushAwayFrom", at = @At("HEAD"), cancellable = true, require = 0)
    private void zenith$noPush(Entity other, CallbackInfo ci) {
        if (NoPush.blocksEntities((Entity) (Object) this)) ci.cancel();
    }

    /** Freecam: the mouse rotates the camera instead of the player. */
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true, require = 0)
    private void zenith$freecamLook(double cursorDeltaX, double cursorDeltaY, CallbackInfo ci) {
        if (Freecam.active() && (Object) this == MinecraftClient.getInstance().player) {
            Freecam.look(cursorDeltaX, cursorDeltaY);
            ci.cancel();
        }
    }
}
