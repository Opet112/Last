package dev.zenith.mixin;

import dev.zenith.ZenithClient;
import net.minecraft.client.network.ClientCommonNetworkHandler;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Outgoing packet hook (used by Blink). */
@Mixin(ClientCommonNetworkHandler.class)
public abstract class ClientCommonNetworkHandlerMixin {
    @Inject(method = "sendPacket", at = @At("HEAD"), cancellable = true, require = 0)
    private void zenith$onSend(Packet<?> packet, CallbackInfo ci) {
        if (ZenithClient.modules().dispatchSend(packet)) ci.cancel();
    }
}
