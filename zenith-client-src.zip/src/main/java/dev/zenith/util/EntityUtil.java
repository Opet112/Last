package dev.zenith.util;

import dev.zenith.ZenithClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.Locale;

public final class EntityUtil {
    private EntityUtil() {}

    public static boolean isFriend(Entity e) {
        return e instanceof PlayerEntity p
                && ZenithClient.friends().contains(p.getName().getString().toLowerCase(Locale.ROOT));
    }

    /** Closest living, non-friend player within {@code range}, or null. */
    public static PlayerEntity nearestPlayer(double range) {
        var mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return null;
        PlayerEntity best = null;
        double bestDist = range;
        for (PlayerEntity other : mc.world.getPlayers()) {
            if (other == mc.player || !other.isAlive() || isFriend(other)) continue;
            double d = mc.player.distanceTo(other);
            if (d <= bestDist) { bestDist = d; best = other; }
        }
        return best;
    }

    public static boolean isMoving() {
        var o = MinecraftClient.getInstance().options;
        return o.forwardKey.isPressed() || o.backKey.isPressed() || o.leftKey.isPressed() || o.rightKey.isPressed();
    }

    /** True when the player is about to walk off the edge of a block. */
    public static boolean atEdge(ClientPlayerEntity p) {
        var world = MinecraftClient.getInstance().world;
        if (world == null || !p.isOnGround()) return false;
        Vec3d v = p.getVelocity();
        Box box = p.getBoundingBox().offset(v.x * 2.5, -0.5, v.z * 2.5);
        return world.isSpaceEmpty(p, box);
    }

    /** {yaw, pitch} needed to look at {@code target} from the player's eyes. */
    public static float[] rotationsTo(ClientPlayerEntity p, Vec3d target) {
        Vec3d eye = p.getEyePos();
        double dx = target.x - eye.x, dy = target.y - eye.y, dz = target.z - eye.z;
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, flat));
        return new float[]{yaw, pitch};
    }

    /** Closest point of {@code box} to the player's eyes (centre if the eyes are inside it) - looks more natural than aiming at the centre. */
    public static Vec3d aimPoint(ClientPlayerEntity p, Box box) {
        Vec3d eye = p.getEyePos();
        Vec3d c = box.getCenter();
        double x = Math.max(box.minX, Math.min(box.maxX, eye.x));
        double y = Math.max(box.minY, Math.min(box.maxY, eye.y));
        double z = Math.max(box.minZ, Math.min(box.maxZ, eye.z));
        Vec3d near = new Vec3d(x, y, z);
        if (near.squaredDistanceTo(eye) < 1.0E-4) return c;
        // blend with the centre so the aim point is not stuck to a box corner
        return near.add(c.subtract(near).multiply(0.35));
    }

    /** Rough tier ranking of tools/armor from their registry path (e.g. "diamond_sword"). */
    public static int materialRank(String path) {
        if (path.startsWith("netherite")) return 7;
        if (path.startsWith("diamond")) return 6;
        if (path.startsWith("iron")) return 5;
        if (path.startsWith("copper")) return 4;
        if (path.startsWith("chainmail") || path.startsWith("golden")) return 3;
        if (path.startsWith("stone") || path.startsWith("turtle")) return 2;
        if (path.startsWith("wooden") || path.startsWith("leather")) return 1;
        return 0;
    }
}
