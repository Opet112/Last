package dev.zenith.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public final class BlockUtil {
    private BlockUtil() {}

    public static boolean canPlaceAt(BlockPos pos) {
        var world = MinecraftClient.getInstance().world;
        return world != null && world.getBlockState(pos).isReplaceable();
    }

    /** True if some neighbouring block is solid enough to place against. */
    public static boolean hasSupport(BlockPos pos) {
        var world = MinecraftClient.getInstance().world;
        if (world == null) return false;
        for (Direction d : Direction.values()) {
            if (!world.getBlockState(pos.offset(d)).isReplaceable()) return true;
        }
        return false;
    }

    /** The face of {@code pos} that is actually visible from {@code eye} and closest to it (UP if none). */
    public static Direction bestFace(BlockPos pos, Vec3d eye) {
        Direction best = Direction.UP;
        double bestDist = Double.MAX_VALUE;
        for (Direction d : Direction.values()) {
            Vec3d center = Vec3d.ofCenter(pos).add(Vec3d.of(d.getVector()).multiply(0.5));
            Vec3d normal = Vec3d.of(d.getVector());
            if (eye.subtract(center).dotProduct(normal) <= 0) continue; // eye is behind this face
            double dist = eye.squaredDistanceTo(center);
            if (dist < bestDist) { bestDist = dist; best = d; }
        }
        return best;
    }

    /** Places the block currently held in {@code hand} at {@code pos}. */
    public static boolean place(BlockPos pos, Hand hand, boolean swing) {
        var mc = MinecraftClient.getInstance();
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || !canPlaceAt(pos)) return false;
        for (Direction d : Direction.values()) {
            BlockPos neighbor = pos.offset(d);
            if (mc.world.getBlockState(neighbor).isReplaceable()) continue;
            Direction face = d.getOpposite();
            Vec3d hit = Vec3d.ofCenter(neighbor).add(Vec3d.of(face.getVector()).multiply(0.5));
            mc.interactionManager.interactBlock(p, hand, new BlockHitResult(hit, face, neighbor, false));
            if (swing) p.swingHand(hand);
            return true;
        }
        return false;
    }
}
